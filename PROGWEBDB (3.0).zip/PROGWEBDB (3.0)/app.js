const express = require("express");
const passport = require("passport");
const LocalStrategy = require("passport-local");
const Administrador = require('./models/administrador');
const Produto = require('./models/produto');
const expressSession = require("express-session");
const path = require("path");
const methodOverride = require('method-override')



const app = express();
app.use(express.static('public'))

app.set("view engine", 'ejs');





app.use(express.urlencoded({extended: true}));
app.use(require('cookie-parser')());
app.use(require('body-parser').urlencoded({ extended: true }));
app.use(require('express-session')({ secret: 'keyboard cat', resave: true, saveUninitialized: true }));
app.use(passport.initialize());
app.use(passport.session());


passport.use(new LocalStrategy(Administrador.authenticate()));


passport.serializeUser(Administrador.serializeUser());
passport.deserializeUser(Administrador.deserializeUser());

const isLoggedIn = (req, res, next) => {
    if(req.isAuthenticated()){
        return next();
    }
    res.redirect("/login");
}

app.get("/", (req, res) => {
    res.render("home");
});

app.get("/register", (req, res) => {
    res.render("register");
});

app.get("/produto", (req, res) => {
    res.render("produto");
});

app.post("/register", (req, res) => {
    Administrador.register(new Administrador({username: req.body.username}), req.body.password, (err, user) => {
        if(err){
            console.log(err);
            res.render("register");
        } else {
            passport.authenticate("local")(req, res, ()=>{
                res.redirect("/home");
            });
        }
    })
});

app.get("/login", (req, res) => {
    res.render("login");
});

app.post("/login", passport.authenticate("local", {
    successRedirect: "/home",
    failureRedirect: "/login"
}));

app.get("/logout", (req, res) => {
    req.logout();
    res.redirect('/');
});

app.get("/home",  isLoggedIn, (req, res) => {
    res.render("home");
});

app.listen(3000, () => {console.log('Servidor ligado na porta 3000!')});