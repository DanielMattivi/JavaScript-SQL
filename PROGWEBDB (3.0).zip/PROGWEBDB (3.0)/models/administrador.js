const {mongoose} = require('../db')

const passportLocalMongoose = require('passport-local-mongoose');

const administradorSchema = new mongoose.Schema({
    username: String,
    password: String
});


administradorSchema.plugin(passportLocalMongoose);
const Administrador = mongoose.model("Administrador", administradorSchema)


module.exports = Administrador